import { Router } from 'express';
import { getMyNotifications, markNotificationRead } from '../controllers/notificationsController.js';
import { protect } from '../middleware/auth.js';

const router = Router();
router.get('/', protect, getMyNotifications);
router.put('/:id/read', protect, markNotificationRead);
export default router;
