import { Router } from 'express';
import { login, logout, refresh, register } from '../controllers/authController.js';
import { loginValidator, refreshValidator, registerValidator } from '../validators/authValidators.js';
import { validate } from '../middleware/validate.js';

const router = Router();
router.post('/register', registerValidator, validate, register);
router.post('/login', loginValidator, validate, login);
router.post('/refresh', refreshValidator, validate, refresh);
router.post('/logout', logout);
export default router;
