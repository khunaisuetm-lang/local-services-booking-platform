import { Router } from 'express';
import { createService, deleteService, getServiceById, listServices, updateService } from '../controllers/servicesController.js';
import { authorize, protect } from '../middleware/auth.js';
import { validate } from '../middleware/validate.js';
import { serviceValidator } from '../validators/serviceValidators.js';

const router = Router();
router.get('/', listServices);
router.get('/:id', getServiceById);
router.post('/', protect, authorize('provider'), serviceValidator, validate, createService);
router.put('/:id', protect, authorize('provider'), serviceValidator, validate, updateService);
router.delete('/:id', protect, authorize('provider'), deleteService);
export default router;
