import { Router } from 'express';
import { createBooking, exportBookingsCsv, getMyBookings, updateBookingStatus } from '../controllers/bookingsController.js';
import { protect } from '../middleware/auth.js';
import { validate } from '../middleware/validate.js';
import { bookingCreateValidator, bookingStatusValidator } from '../validators/bookingValidators.js';

const router = Router();
router.get('/me', protect, getMyBookings);
router.get('/export/csv', protect, exportBookingsCsv);
router.post('/', protect, bookingCreateValidator, validate, createBooking);
router.put('/:id/status', protect, bookingStatusValidator, validate, updateBookingStatus);
export default router;
