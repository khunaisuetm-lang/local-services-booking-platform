import { Router } from 'express';
import { createReview, getProviderReviews } from '../controllers/reviewsController.js';
import { protect } from '../middleware/auth.js';
import { validate } from '../middleware/validate.js';
import { reviewValidator } from '../validators/reviewValidators.js';

const router = Router();
router.get('/:providerId', getProviderReviews);
router.post('/', protect, reviewValidator, validate, createReview);
export default router;
