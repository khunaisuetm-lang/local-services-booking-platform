import { Router } from 'express';
import { getProviderStats } from '../controllers/dashboardController.js';
import { authorize, protect } from '../middleware/auth.js';

const router = Router();
router.get('/provider-stats', protect, authorize('provider'), getProviderStats);
export default router;
