import { Router } from 'express';
import { changePassword, getProfile, getPublicProviderProfile, toggleFavoriteProvider, updateProfile } from '../controllers/usersController.js';
import { protect } from '../middleware/auth.js';
import { validate } from '../middleware/validate.js';
import { changePasswordValidator, updateProfileValidator } from '../validators/userValidators.js';

const router = Router();
router.get('/providers/:providerId/public-profile', getPublicProviderProfile);
router.get('/profile', protect, getProfile);
router.put('/profile', protect, updateProfileValidator, validate, updateProfile);
router.put('/change-password', protect, changePasswordValidator, validate, changePassword);
router.post('/favorites/:providerId', protect, toggleFavoriteProvider);
export default router;
