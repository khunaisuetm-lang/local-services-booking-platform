import { Router } from 'express';
import { getProviderAvailability, upsertAvailability } from '../controllers/availabilityController.js';
import { authorize, protect } from '../middleware/auth.js';
import { validate } from '../middleware/validate.js';
import { availabilityValidator } from '../validators/availabilityValidators.js';

const router = Router();
router.get('/:providerId', getProviderAvailability);
router.post('/', protect, authorize('provider'), availabilityValidator, validate, upsertAvailability);
export default router;
