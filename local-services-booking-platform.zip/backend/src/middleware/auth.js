import { ApiError } from '../utils/ApiError.js';
import { asyncHandler } from '../utils/asyncHandler.js';
import { verifyAccessToken } from '../utils/token.js';
import { User } from '../models/User.js';

export const protect = asyncHandler(async (req, res, next) => {
  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith('Bearer ')) throw new ApiError(401, 'Authorization token is required.');
  const token = authHeader.split(' ')[1];
  const payload = verifyAccessToken(token);
  const user = await User.findById(payload.sub).select('-passwordHash -refreshToken');
  if (!user) throw new ApiError(401, 'User not found or token no longer valid.');
  req.user = user;
  next();
});

export const authorize = (...roles) => (req, res, next) => {
  if (!req.user || !roles.includes(req.user.role)) return next(new ApiError(403, 'You do not have permission to perform this action.'));
  next();
};
