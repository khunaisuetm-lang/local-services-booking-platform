import dotenv from 'dotenv';
import bcrypt from 'bcryptjs';
import { connectDB } from './config/db.js';
import { User } from './models/User.js';
import { Service } from './models/Service.js';
import { AvailabilitySlot } from './models/AvailabilitySlot.js';
import { Booking } from './models/Booking.js';
import { Review } from './models/Review.js';
import { Notification } from './models/Notification.js';

dotenv.config();
await connectDB();
await Promise.all([User.deleteMany({}), Service.deleteMany({}), AvailabilitySlot.deleteMany({}), Booking.deleteMany({}), Review.deleteMany({}), Notification.deleteMany({})]);
const providerPassword = await bcrypt.hash('Provider@123', 12);
const customerPassword = await bcrypt.hash('Customer@123', 12);
const provider = await User.create({ name: 'Sara Tutor', email: 'provider@example.com', passwordHash: providerPassword, role: 'provider', bio: 'Math and coding tutor', location: 'Lahore' });
const customer = await User.create({ name: 'Ali Customer', email: 'customer@example.com', passwordHash: customerPassword, role: 'customer', bio: 'Looking for quality tutors', location: 'Karachi' });
const service = await Service.create({ providerId: provider._id, title: 'React Mentoring Session', description: 'Hands-on mentoring for React and frontend architecture.', category: 'Tutoring', durationMinutes: 60, price: 2500, isActive: true });
await AvailabilitySlot.insertMany([
  { providerId: provider._id, dayOfWeek: 1, startTime: '10:00', endTime: '11:00', isBooked: false },
  { providerId: provider._id, dayOfWeek: 3, startTime: '14:00', endTime: '15:00', isBooked: false },
]);
console.log('Seed complete');
console.log({ providerEmail: provider.email, customerEmail: customer.email, password: 'Provider@123 / Customer@123', serviceId: service._id.toString() });
process.exit(0);
