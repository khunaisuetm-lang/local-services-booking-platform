import jwt from 'jsonwebtoken';

export const generateAccessToken = (user) => jwt.sign(
  { sub: user._id.toString(), role: user.role },
  process.env.JWT_ACCESS_SECRET,
  { expiresIn: process.env.ACCESS_TOKEN_TTL || '15m' }
);

export const generateRefreshToken = (user) => jwt.sign(
  { sub: user._id.toString() },
  process.env.JWT_REFRESH_SECRET,
  { expiresIn: process.env.REFRESH_TOKEN_TTL || '7d' }
);

export const verifyAccessToken = (token) => jwt.verify(token, process.env.JWT_ACCESS_SECRET);
export const verifyRefreshToken = (token) => jwt.verify(token, process.env.JWT_REFRESH_SECRET);
