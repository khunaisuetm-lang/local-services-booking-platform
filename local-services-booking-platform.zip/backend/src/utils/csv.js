const escapeValue = (value) => `"${String(value ?? '').replace(/"/g, '""')}"`;
export const toCSV = (rows) => {
  if (!rows.length) return '';
  const headers = Object.keys(rows[0]);
  return [headers.map(escapeValue).join(','), ...rows.map((row) => headers.map((header) => escapeValue(row[header])).join(','))].join('\n');
};
