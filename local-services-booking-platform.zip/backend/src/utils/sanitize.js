import sanitizeHtml from 'sanitize-html';

export const sanitizeText = (value) => {
  if (typeof value !== 'string') return value;
  return sanitizeHtml(value, { allowedTags: [], allowedAttributes: {} }).trim();
};

export const sanitizeObjectStrings = (obj = {}) => Object.fromEntries(
  Object.entries(obj).map(([key, value]) => [key, typeof value === 'string' ? sanitizeText(value) : value])
);
