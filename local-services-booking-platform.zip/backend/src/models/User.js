import mongoose from 'mongoose';

const userSchema = new mongoose.Schema({
  name: { type: String, required: true, trim: true },
  email: { type: String, required: true, unique: true, lowercase: true, trim: true },
  passwordHash: { type: String, required: true },
  profilePicUrl: { type: String, default: '' },
  role: { type: String, enum: ['provider', 'customer'], required: true },
  bio: { type: String, default: '' },
  location: { type: String, default: '' },
  refreshToken: { type: String, default: null },
  favoriteProviders: [{ type: mongoose.Schema.Types.ObjectId, ref: 'User' }],
}, { timestamps: true });

export const User = mongoose.model('User', userSchema);
