import mongoose from 'mongoose';

const bookingSchema = new mongoose.Schema({
  customerId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  providerId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  serviceId: { type: mongoose.Schema.Types.ObjectId, ref: 'Service', required: true },
  slotId: { type: mongoose.Schema.Types.ObjectId, ref: 'AvailabilitySlot', required: true },
  status: { type: String, enum: ['pending', 'confirmed', 'completed', 'declined', 'cancelled'], default: 'pending' },
  notes: { type: String, default: '' },
  slotSnapshot: { dayOfWeek: Number, startTime: String, endTime: String },
}, { timestamps: true });

export const Booking = mongoose.model('Booking', bookingSchema);
