import mongoose from 'mongoose';

const availabilitySlotSchema = new mongoose.Schema({
  providerId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  dayOfWeek: { type: Number, required: true, min: 0, max: 6 },
  startTime: { type: String, required: true },
  endTime: { type: String, required: true },
  isBooked: { type: Boolean, default: false },
}, { timestamps: true });

availabilitySlotSchema.index({ providerId: 1, dayOfWeek: 1, startTime: 1, endTime: 1 }, { unique: true });
export const AvailabilitySlot = mongoose.model('AvailabilitySlot', availabilitySlotSchema);
