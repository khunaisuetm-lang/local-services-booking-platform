import bcrypt from 'bcryptjs';
import { User } from '../models/User.js';
import { ApiError } from '../utils/ApiError.js';
import { asyncHandler } from '../utils/asyncHandler.js';
import { sanitizeObjectStrings } from '../utils/sanitize.js';
import { generateAccessToken, generateRefreshToken, verifyRefreshToken } from '../utils/token.js';

const buildAuthResponse = (user) => {
  const safeUser = {
    _id: user._id,
    name: user.name,
    email: user.email,
    role: user.role,
    profilePicUrl: user.profilePicUrl,
    bio: user.bio,
    location: user.location,
    favoriteProviders: user.favoriteProviders,
    createdAt: user.createdAt,
  };
  return { user: safeUser, accessToken: generateAccessToken(user), refreshToken: generateRefreshToken(user) };
};

export const register = asyncHandler(async (req, res) => {
  const payload = sanitizeObjectStrings(req.body);
  const existing = await User.findOne({ email: payload.email });
  if (existing) throw new ApiError(409, 'Email already registered.');
  const passwordHash = await bcrypt.hash(payload.password, 12);
  const user = await User.create({
    name: payload.name,
    email: payload.email,
    passwordHash,
    role: payload.role,
    location: payload.location || '',
    bio: payload.bio || '',
  });
  const auth = buildAuthResponse(user);
  user.refreshToken = auth.refreshToken;
  await user.save();
  res.status(201).json(auth);
});

export const login = asyncHandler(async (req, res) => {
  const payload = sanitizeObjectStrings(req.body);
  const user = await User.findOne({ email: payload.email });
  if (!user) throw new ApiError(401, 'Invalid email or password.');
  const isMatch = await bcrypt.compare(payload.password, user.passwordHash);
  if (!isMatch) throw new ApiError(401, 'Invalid email or password.');
  const auth = buildAuthResponse(user);
  user.refreshToken = auth.refreshToken;
  await user.save();
  res.json(auth);
});

export const refresh = asyncHandler(async (req, res) => {
  const { refreshToken } = req.body;
  const payload = verifyRefreshToken(refreshToken);
  const user = await User.findById(payload.sub);
  if (!user || user.refreshToken !== refreshToken) throw new ApiError(401, 'Refresh token is invalid or expired.');
  res.json({ accessToken: generateAccessToken(user) });
});

export const logout = asyncHandler(async (req, res) => {
  const { refreshToken } = req.body || {};
  if (refreshToken) {
    try {
      const payload = verifyRefreshToken(refreshToken);
      const user = await User.findById(payload.sub);
      if (user) {
        user.refreshToken = null;
        await user.save();
      }
    } catch {
      // ignore invalid refresh token at logout
    }
  }
  res.json({ message: 'Logged out successfully.' });
});
