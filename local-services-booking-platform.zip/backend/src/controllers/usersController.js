import bcrypt from 'bcryptjs';
import { User } from '../models/User.js';
import { Service } from '../models/Service.js';
import { AvailabilitySlot } from '../models/AvailabilitySlot.js';
import { Booking } from '../models/Booking.js';
import { Review } from '../models/Review.js';
import { ApiError } from '../utils/ApiError.js';
import { asyncHandler } from '../utils/asyncHandler.js';
import { sanitizeObjectStrings } from '../utils/sanitize.js';

const getProviderStatsData = async (providerId) => {
  const bookings = await Booking.find({ providerId });
  const total = bookings.length;
  const completed = bookings.filter((item) => item.status === 'completed').length;
  const pending = bookings.filter((item) => item.status === 'pending').length;
  return {
    totalBookings: total,
    completedBookings: completed,
    pendingBookings: pending,
    completionRate: total ? Math.round((completed / total) * 100) : 0,
  };
};

export const getProfile = asyncHandler(async (req, res) => {
  const user = await User.findById(req.user._id).select('-passwordHash -refreshToken').populate('favoriteProviders', 'name role location profilePicUrl bio');
  res.json(user);
});

export const updateProfile = asyncHandler(async (req, res) => {
  const updates = sanitizeObjectStrings(req.body);
  const user = await User.findById(req.user._id);
  if (!user) throw new ApiError(404, 'User not found.');
  Object.assign(user, {
    name: updates.name ?? user.name,
    bio: updates.bio ?? user.bio,
    location: updates.location ?? user.location,
    profilePicUrl: updates.profilePicUrl ?? user.profilePicUrl,
  });
  await user.save();
  res.json({ message: 'Profile updated successfully.' });
});

export const changePassword = asyncHandler(async (req, res) => {
  const user = await User.findById(req.user._id);
  if (!user) throw new ApiError(404, 'User not found.');
  const isMatch = await bcrypt.compare(req.body.currentPassword, user.passwordHash);
  if (!isMatch) throw new ApiError(400, 'Current password is incorrect.');
  user.passwordHash = await bcrypt.hash(req.body.newPassword, 12);
  await user.save();
  res.json({ message: 'Password updated successfully.' });
});

export const toggleFavoriteProvider = asyncHandler(async (req, res) => {
  if (req.user.role !== 'customer') throw new ApiError(403, 'Only customers can manage favorites.');
  const provider = await User.findOne({ _id: req.params.providerId, role: 'provider' });
  if (!provider) throw new ApiError(404, 'Provider not found.');
  const user = await User.findById(req.user._id);
  const exists = user.favoriteProviders.some((id) => id.toString() === provider._id.toString());
  if (exists) user.favoriteProviders = user.favoriteProviders.filter((id) => id.toString() !== provider._id.toString());
  else user.favoriteProviders.push(provider._id);
  await user.save();
  res.json({ message: exists ? 'Provider removed from favorites.' : 'Provider added to favorites.' });
});

export const getPublicProviderProfile = asyncHandler(async (req, res) => {
  const provider = await User.findOne({ _id: req.params.providerId, role: 'provider' }).select('-passwordHash -refreshToken');
  if (!provider) throw new ApiError(404, 'Provider not found.');
  const [services, availability, reviews, ratingAgg, stats] = await Promise.all([
    Service.find({ providerId: provider._id, isActive: true }).sort({ createdAt: -1 }),
    AvailabilitySlot.find({ providerId: provider._id }).sort({ dayOfWeek: 1, startTime: 1 }),
    Review.find({ providerId: provider._id }).populate('customerId', 'name profilePicUrl').sort({ createdAt: -1 }),
    Review.aggregate([{ $match: { providerId: provider._id } }, { $group: { _id: '$providerId', avgRating: { $avg: '$rating' }, reviewCount: { $sum: 1 } } }]),
    getProviderStatsData(provider._id),
  ]);
  res.json({ provider, services, availability, reviews, rating: ratingAgg[0] || { avgRating: 0, reviewCount: 0 }, stats });
});
