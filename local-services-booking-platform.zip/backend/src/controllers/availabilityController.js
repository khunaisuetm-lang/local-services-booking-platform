import { AvailabilitySlot } from '../models/AvailabilitySlot.js';
import { asyncHandler } from '../utils/asyncHandler.js';
import { sanitizeObjectStrings } from '../utils/sanitize.js';

export const upsertAvailability = asyncHandler(async (req, res) => {
  await AvailabilitySlot.deleteMany({ providerId: req.user._id, isBooked: false });
  const saved = await AvailabilitySlot.insertMany(req.body.slots.map((slot) => ({ ...sanitizeObjectStrings(slot), providerId: req.user._id })), { ordered: false });
  res.status(201).json(saved);
});

export const getProviderAvailability = asyncHandler(async (req, res) => {
  const slots = await AvailabilitySlot.find({ providerId: req.params.providerId }).sort({ dayOfWeek: 1, startTime: 1 });
  res.json(slots);
});
