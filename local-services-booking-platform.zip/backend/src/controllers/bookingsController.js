import { Booking } from '../models/Booking.js';
import { Service } from '../models/Service.js';
import { AvailabilitySlot } from '../models/AvailabilitySlot.js';
import { Notification } from '../models/Notification.js';
import { User } from '../models/User.js';
import { ApiError } from '../utils/ApiError.js';
import { asyncHandler } from '../utils/asyncHandler.js';
import { sanitizeObjectStrings } from '../utils/sanitize.js';
import { toCSV } from '../utils/csv.js';
import { sendMail } from '../config/mailer.js';

const bookingPopulate = [
  { path: 'customerId', select: 'name email profilePicUrl' },
  { path: 'providerId', select: 'name email profilePicUrl location' },
  { path: 'serviceId', select: 'title category durationMinutes price' },
  { path: 'slotId', select: 'dayOfWeek startTime endTime isBooked' },
];

const createNotification = async (userId, title, message, type, metadata = {}) => {
  await Notification.create({ userId, title, message, type, metadata });
};

export const createBooking = asyncHandler(async (req, res) => {
  if (req.user.role !== 'customer') throw new ApiError(403, 'Only customers can create bookings.');
  const payload = sanitizeObjectStrings(req.body);
  const service = await Service.findById(payload.serviceId).populate('providerId', 'name email');
  if (!service || !service.isActive) throw new ApiError(404, 'Service not found or inactive.');
  const slot = await AvailabilitySlot.findOneAndUpdate(
    { _id: payload.slotId, providerId: service.providerId._id, isBooked: false },
    { isBooked: true },
    { new: true }
  );
  if (!slot) throw new ApiError(409, 'Selected slot is no longer available.');
  const booking = await Booking.create({
    customerId: req.user._id,
    providerId: service.providerId._id,
    serviceId: service._id,
    slotId: slot._id,
    notes: payload.notes || '',
    slotSnapshot: { dayOfWeek: slot.dayOfWeek, startTime: slot.startTime, endTime: slot.endTime },
  });
  await Promise.all([
    createNotification(service.providerId._id, 'New booking request', `${req.user.name} requested ${service.title}.`, 'booking', { bookingId: booking._id }),
    sendMail({
      to: service.providerId.email,
      subject: 'New booking request',
      html: `<p>${req.user.name} requested your service <strong>${service.title}</strong>.</p>`,
    }),
  ]);
  const populated = await Booking.findById(booking._id).populate(bookingPopulate);
  res.status(201).json(populated);
});

export const getMyBookings = asyncHandler(async (req, res) => {
  const filter = req.user.role === 'provider' ? { providerId: req.user._id } : { customerId: req.user._id };
  const bookings = await Booking.find(filter).populate(bookingPopulate).sort({ createdAt: -1 });
  res.json(bookings);
});

export const updateBookingStatus = asyncHandler(async (req, res) => {
  const booking = await Booking.findById(req.params.id).populate(bookingPopulate);
  if (!booking) throw new ApiError(404, 'Booking not found.');
  const { status } = req.body;
  const isProvider = booking.providerId._id.toString() === req.user._id.toString();
  const isCustomer = booking.customerId._id.toString() === req.user._id.toString();
  if (!isProvider && !isCustomer) throw new ApiError(403, 'Not allowed to update this booking.');
  const providerAllowed = ['confirmed', 'completed', 'declined'];
  const customerAllowed = ['cancelled'];
  if (isProvider && !providerAllowed.includes(status)) throw new ApiError(400, 'Provider cannot set this status.');
  if (isCustomer && !customerAllowed.includes(status)) throw new ApiError(400, 'Customer can only cancel bookings.');
  booking.status = status;
  await booking.save();
  if (['declined', 'cancelled'].includes(status)) {
    await AvailabilitySlot.findByIdAndUpdate(booking.slotId._id, { isBooked: false });
  }
  const targetUser = isProvider ? booking.customerId : booking.providerId;
  const actorName = isProvider ? booking.providerId.name : booking.customerId.name;
  await Promise.all([
    createNotification(targetUser._id, 'Booking status updated', `${actorName} changed your booking to ${status}.`, 'booking', { bookingId: booking._id }),
    sendMail({
      to: targetUser.email,
      subject: 'Booking status updated',
      html: `<p>Your booking for <strong>${booking.serviceId.title}</strong> is now <strong>${status}</strong>.</p>`,
    }),
  ]);
  const refreshed = await Booking.findById(booking._id).populate(bookingPopulate);
  res.json(refreshed);
});

export const exportBookingsCsv = asyncHandler(async (req, res) => {
  const filter = req.user.role === 'provider' ? { providerId: req.user._id } : { customerId: req.user._id };
  const bookings = await Booking.find(filter).populate(bookingPopulate).sort({ createdAt: -1 });
  const rows = bookings.map((item) => ({
    bookingId: item._id.toString(),
    service: item.serviceId?.title,
    customer: item.customerId?.name,
    provider: item.providerId?.name,
    status: item.status,
    dayOfWeek: item.slotSnapshot?.dayOfWeek,
    startTime: item.slotSnapshot?.startTime,
    endTime: item.slotSnapshot?.endTime,
    createdAt: item.createdAt.toISOString(),
  }));
  res.setHeader('Content-Type', 'text/csv');
  res.setHeader('Content-Disposition', 'attachment; filename=booking-history.csv');
  res.send(toCSV(rows));
});
