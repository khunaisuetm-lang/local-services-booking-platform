import { Booking } from '../models/Booking.js';
import { asyncHandler } from '../utils/asyncHandler.js';

export const getProviderStats = asyncHandler(async (req, res) => {
  const bookings = await Booking.find({ providerId: req.user._id });
  const total = bookings.length;
  const completed = bookings.filter((item) => item.status === 'completed').length;
  const confirmed = bookings.filter((item) => item.status === 'confirmed').length;
  const pending = bookings.filter((item) => item.status === 'pending').length;
  res.json({
    totalBookings: total,
    completedBookings: completed,
    confirmedBookings: confirmed,
    pendingBookings: pending,
    completionRate: total ? Math.round((completed / total) * 100) : 0,
    responseTimeLabel: pending ? 'Pending responses need attention' : 'Under 24 hours',
  });
});
