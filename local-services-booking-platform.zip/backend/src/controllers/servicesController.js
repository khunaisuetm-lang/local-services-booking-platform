import mongoose from 'mongoose';
import { Service } from '../models/Service.js';
import { Review } from '../models/Review.js';
import { AvailabilitySlot } from '../models/AvailabilitySlot.js';
import { ApiError } from '../utils/ApiError.js';
import { asyncHandler } from '../utils/asyncHandler.js';
import { sanitizeObjectStrings } from '../utils/sanitize.js';

const dayScore = (slots = []) => {
  const openSlots = slots.filter((slot) => !slot.isBooked).map((slot) => slot.dayOfWeek);
  return openSlots.length ? Math.min(...openSlots) : 99;
};

export const listServices = asyncHandler(async (req, res) => {
  const { search = '', category, minPrice, maxPrice, location = '', minRating = 0, sort = 'latest', page = 1, limit = 6 } = req.query;
  const mongoFilter = { isActive: true };
  if (category) mongoFilter.category = category;
  if (minPrice || maxPrice) {
    mongoFilter.price = {};
    if (minPrice) mongoFilter.price.$gte = Number(minPrice);
    if (maxPrice) mongoFilter.price.$lte = Number(maxPrice);
  }
  const services = await Service.find(mongoFilter).populate('providerId', 'name role location profilePicUrl bio').sort({ createdAt: -1 });
  const providerIds = [...new Set(services.map((item) => item.providerId?._id?.toString()).filter(Boolean))].map((id) => new mongoose.Types.ObjectId(id));
  const [ratings, availability] = await Promise.all([
    Review.aggregate([{ $match: { providerId: { $in: providerIds } } }, { $group: { _id: '$providerId', avgRating: { $avg: '$rating' }, reviewCount: { $sum: 1 } } }]),
    AvailabilitySlot.find({ providerId: { $in: providerIds } }),
  ]);
  const ratingMap = new Map(ratings.map((item) => [item._id.toString(), item]));
  const availabilityMap = availability.reduce((acc, slot) => {
    const key = slot.providerId.toString();
    acc[key] ||= [];
    acc[key].push(slot);
    return acc;
  }, {});
  let items = services.map((service) => {
    const providerId = service.providerId?._id?.toString();
    const rating = ratingMap.get(providerId) || { avgRating: 0, reviewCount: 0 };
    return {
      ...service.toObject(),
      provider: service.providerId,
      rating,
      openSlots: (availabilityMap[providerId] || []).filter((slot) => !slot.isBooked).length,
      soonestAvailability: dayScore(availabilityMap[providerId] || []),
    };
  });
  const q = search.toLowerCase().trim();
  const loc = location.toLowerCase().trim();
  items = items.filter((item) => {
    const searchFields = [item.title, item.description, item.category, item.provider?.name].filter(Boolean);
    const matchesSearch = !q || searchFields.some((value) => value.toLowerCase().includes(q));
    const matchesLocation = !loc || (item.provider?.location || '').toLowerCase().includes(loc);
    const matchesRating = (item.rating.avgRating || 0) >= Number(minRating);
    return matchesSearch && matchesLocation && matchesRating;
  });
  const sorters = {
    latest: (a, b) => new Date(b.createdAt) - new Date(a.createdAt),
    price_asc: (a, b) => a.price - b.price,
    rating_desc: (a, b) => (b.rating.avgRating || 0) - (a.rating.avgRating || 0),
    availability_asc: (a, b) => a.soonestAvailability - b.soonestAvailability,
  };
  items.sort(sorters[sort] || sorters.latest);
  const currentPage = Number(page);
  const pageSize = Number(limit);
  const total = items.length;
  const paginated = items.slice((currentPage - 1) * pageSize, currentPage * pageSize);
  res.json({ items: paginated, meta: { page: currentPage, limit: pageSize, total, totalPages: Math.ceil(total / pageSize) || 1 } });
});

export const getServiceById = asyncHandler(async (req, res) => {
  const service = await Service.findById(req.params.id).populate('providerId', 'name location profilePicUrl bio role');
  if (!service) throw new ApiError(404, 'Service not found.');
  res.json(service);
});

export const createService = asyncHandler(async (req, res) => {
  const service = await Service.create({ ...sanitizeObjectStrings(req.body), providerId: req.user._id });
  res.status(201).json(service);
});

export const updateService = asyncHandler(async (req, res) => {
  const service = await Service.findOne({ _id: req.params.id, providerId: req.user._id });
  if (!service) throw new ApiError(404, 'Service not found.');
  Object.assign(service, sanitizeObjectStrings(req.body));
  await service.save();
  res.json(service);
});

export const deleteService = asyncHandler(async (req, res) => {
  const service = await Service.findOneAndDelete({ _id: req.params.id, providerId: req.user._id });
  if (!service) throw new ApiError(404, 'Service not found.');
  res.json({ message: 'Service deleted successfully.' });
});
