import { Review } from '../models/Review.js';
import { Booking } from '../models/Booking.js';
import { ApiError } from '../utils/ApiError.js';
import { asyncHandler } from '../utils/asyncHandler.js';
import { sanitizeObjectStrings } from '../utils/sanitize.js';

export const createReview = asyncHandler(async (req, res) => {
  if (req.user.role !== 'customer') throw new ApiError(403, 'Only customers can leave reviews.');
  const payload = sanitizeObjectStrings(req.body);
  const booking = await Booking.findById(payload.bookingId);
  if (!booking) throw new ApiError(404, 'Booking not found.');
  if (booking.customerId.toString() !== req.user._id.toString()) throw new ApiError(403, 'This booking does not belong to you.');
  if (booking.providerId.toString() !== payload.providerId) throw new ApiError(400, 'Provider mismatch for this booking.');
  if (booking.status !== 'completed') throw new ApiError(400, 'Reviews can only be left after booking completion.');
  const existing = await Review.findOne({ bookingId: booking._id });
  if (existing) throw new ApiError(409, 'A review already exists for this booking.');
  const review = await Review.create({
    bookingId: booking._id,
    customerId: req.user._id,
    providerId: payload.providerId,
    rating: payload.rating,
    comment: payload.comment,
  });
  res.status(201).json(review);
});

export const getProviderReviews = asyncHandler(async (req, res) => {
  const reviews = await Review.find({ providerId: req.params.providerId }).populate('customerId', 'name profilePicUrl').sort({ createdAt: -1 });
  res.json(reviews);
});
