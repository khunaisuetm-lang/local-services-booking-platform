import { body } from 'express-validator';
export const updateProfileValidator = [body('name').optional().trim().isLength({ min: 2 }), body('bio').optional().isLength({ max: 400 }), body('location').optional().isLength({ max: 120 }), body('profilePicUrl').optional({ nullable: true, checkFalsy: true }).isURL()];
export const changePasswordValidator = [body('currentPassword').notEmpty(), body('newPassword').isLength({ min: 8 })];
