import { body } from 'express-validator';
export const availabilityValidator = [body('slots').isArray({ min: 1 }), body('slots.*.dayOfWeek').isInt({ min: 0, max: 6 }), body('slots.*.startTime').matches(/^([01]\d|2[0-3]):([0-5]\d)$/), body('slots.*.endTime').matches(/^([01]\d|2[0-3]):([0-5]\d)$/)];
