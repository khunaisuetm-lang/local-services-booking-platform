import { body } from 'express-validator';
export const bookingCreateValidator = [body('serviceId').isMongoId(), body('slotId').isMongoId(), body('notes').optional().isLength({ max: 500 })];
export const bookingStatusValidator = [body('status').isIn(['confirmed', 'completed', 'declined', 'cancelled'])];
