import { body } from 'express-validator';
export const reviewValidator = [body('bookingId').isMongoId(), body('providerId').isMongoId(), body('rating').isInt({ min: 1, max: 5 }), body('comment').trim().isLength({ min: 3, max: 500 })];
