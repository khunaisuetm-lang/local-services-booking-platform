import { body } from 'express-validator';
export const serviceValidator = [body('title').trim().isLength({ min: 3 }), body('description').trim().isLength({ min: 10 }), body('category').trim().notEmpty(), body('durationMinutes').isInt({ min: 15 }), body('price').isFloat({ min: 0 }), body('isActive').optional().isBoolean()];
