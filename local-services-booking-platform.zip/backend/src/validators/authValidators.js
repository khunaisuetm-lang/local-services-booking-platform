import { body } from 'express-validator';
export const registerValidator = [body('name').trim().isLength({ min: 2 }), body('email').isEmail().normalizeEmail(), body('password').isLength({ min: 8 }), body('role').isIn(['provider', 'customer'])];
export const loginValidator = [body('email').isEmail().normalizeEmail(), body('password').notEmpty()];
export const refreshValidator = [body('refreshToken').notEmpty()];
