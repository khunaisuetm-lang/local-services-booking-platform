# Local Services Booking Platform

Production-ready MERN assignment solution for the ITSimplera Solutions Week 4 Full Stack Internship task.

## Stack
- Frontend: React + Vite + Bootstrap + Context API + Axios
- Backend: Node.js + Express + MongoDB + Mongoose
- Security: JWT auth, refresh tokens, bcrypt password hashing, server validation, input sanitization, protected routes

## Roles
- Customer: browse providers, book services, manage bookings, save favorites, leave reviews after completion
- Provider: manage services, define weekly availability, approve/decline bookings, mark completed jobs, monitor dashboard stats

## Implemented advanced features
1. Search and filter providers/services
2. Sorting and pagination on listings
3. Favorite/save provider flow
4. In-app notification center
5. CSV export of booking history
6. Email notifications using Nodemailer
7. Availability schedule visualization

## Folder structure
- `frontend/` React app
- `backend/` Express API
- `docs/` ERD and implementation notes
- `backend/postman/` Postman collection

## Environment files
### Backend `.env`
```env
PORT=5000
NODE_ENV=development
MONGODB_URI=mongodb://127.0.0.1:27017/local_services_booking
JWT_ACCESS_SECRET=change_me_access_secret
JWT_REFRESH_SECRET=change_me_refresh_secret
ACCESS_TOKEN_TTL=15m
REFRESH_TOKEN_TTL=7d
CLIENT_URL=http://localhost:5173
SMTP_HOST=smtp.ethereal.email
SMTP_PORT=587
SMTP_USER=
SMTP_PASS=
MAIL_FROM=Local Services Platform noreply@example.com
```

### Frontend `.env`
```env
VITE_API_URL=http://localhost:5000/api
```

## Run locally
### 1) Backend
```bash
cd backend
npm install
npm run seed
npm run dev
```

### 2) Frontend
```bash
cd frontend
npm install
npm run dev
```

## Test accounts after seeding
- Provider: `provider@example.com` / `Provider@123`
- Customer: `customer@example.com` / `Customer@123`

## Key API endpoints
- `POST /api/auth/register`
- `POST /api/auth/login`
- `POST /api/auth/refresh`
- `GET /api/users/profile`
- `PUT /api/users/profile`
- `POST /api/services`
- `GET /api/services`
- `POST /api/availability`
- `POST /api/bookings`
- `GET /api/bookings/me`
- `PUT /api/bookings/:id/status`
- `POST /api/reviews`
- `GET /api/notifications`
- `GET /api/dashboard/provider-stats`

## Notes
- Reviews are restricted to completed bookings only.
- Double-booking protection is enforced server-side by atomically reserving the slot.
- Unbooked provider slots can be replaced via the availability manager.
