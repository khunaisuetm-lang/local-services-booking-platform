# Implementation Notes

## Security
- JWT access + refresh token flow
- Password hashing with bcryptjs
- express-validator request validation
- sanitize-html based text sanitization
- role-based route guards in backend and frontend

## Booking workflow
- pending -> confirmed -> completed
- pending -> declined
- pending/confirmed -> cancelled
- slot unlocks again on declined/cancelled

## Frontend flow
- Home search page with sort and pagination
- Provider profile with services, availability and reviews
- Booking checkout with slot selection
- Customer bookings page with review submission
- Provider dashboard with service management, availability and request handling
- Notification and favorites pages
