# ER Diagram

```mermaid
erDiagram
  USER ||--o{ SERVICE : creates
  USER ||--o{ AVAILABILITY_SLOT : owns
  USER ||--o{ BOOKING : customer_books
  USER ||--o{ BOOKING : provider_receives
  SERVICE ||--o{ BOOKING : booked_as
  AVAILABILITY_SLOT ||--o{ BOOKING : reserved_in
  BOOKING ||--o| REVIEW : produces
  USER ||--o{ REVIEW : writes
  USER ||--o{ NOTIFICATION : receives
```
