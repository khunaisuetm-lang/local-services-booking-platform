import axios from 'axios';

const api = axios.create({
  baseURL: import.meta.env.VITE_API_URL || 'http://localhost:5000/api',
});

let authBridge = {
  getTokens: () => ({ accessToken: null, refreshToken: null }),
  updateAccessToken: () => {},
  clearAuth: () => {},
};

export const attachAuthBridge = (bridge) => {
  authBridge = bridge;
};

api.interceptors.request.use((config) => {
  const { accessToken } = authBridge.getTokens();
  if (accessToken) config.headers.Authorization = `Bearer ${accessToken}`;
  return config;
});

api.interceptors.response.use(
  (response) => response,
  async (error) => {
    const original = error.config;
    if (error.response?.status === 401 && !original?._retry) {
      original._retry = true;
      const { refreshToken } = authBridge.getTokens();
      if (refreshToken) {
        try {
          const { data } = await axios.post(`${api.defaults.baseURL}/auth/refresh`, { refreshToken });
          authBridge.updateAccessToken(data.accessToken);
          original.headers.Authorization = `Bearer ${data.accessToken}`;
          return api(original);
        } catch {
          authBridge.clearAuth();
        }
      }
    }
    return Promise.reject(error);
  }
);

export default api;
