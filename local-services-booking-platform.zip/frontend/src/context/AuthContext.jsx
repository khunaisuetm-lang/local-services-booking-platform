import { createContext, useContext, useEffect, useMemo, useState } from 'react';
import api, { attachAuthBridge } from '../api/client';

const AuthContext = createContext(null);
const STORAGE_KEY = 'localServicesAuth';

export const AuthProvider = ({ children }) => {
  const [auth, setAuth] = useState(() => {
    try {
      return JSON.parse(localStorage.getItem(STORAGE_KEY)) || { user: null, accessToken: null, refreshToken: null };
    } catch {
      return { user: null, accessToken: null, refreshToken: null };
    }
  });

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(auth));
  }, [auth]);

  useEffect(() => {
    attachAuthBridge({
      getTokens: () => ({ accessToken: auth.accessToken, refreshToken: auth.refreshToken }),
      updateAccessToken: (accessToken) => setAuth((prev) => ({ ...prev, accessToken })),
      clearAuth: () => setAuth({ user: null, accessToken: null, refreshToken: null }),
    });
  }, [auth.accessToken, auth.refreshToken]);

  const loadProfile = async () => {
    if (!auth.accessToken) return;
    const { data } = await api.get('/users/profile');
    setAuth((prev) => ({ ...prev, user: data }));
  };

  useEffect(() => {
    loadProfile().catch(() => {});
  }, []);

  const login = async (payload) => {
    const { data } = await api.post('/auth/login', payload);
    setAuth(data);
    return data;
  };

  const register = async (payload) => {
    const { data } = await api.post('/auth/register', payload);
    setAuth(data);
    return data;
  };

  const logout = async () => {
    try {
      if (auth.refreshToken) await api.post('/auth/logout', { refreshToken: auth.refreshToken });
    } catch {}
    setAuth({ user: null, accessToken: null, refreshToken: null });
  };

  const value = useMemo(() => ({ ...auth, isAuthenticated: !!auth.accessToken, login, register, logout, loadProfile }), [auth]);
  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
};

export const useAuth = () => useContext(AuthContext);
