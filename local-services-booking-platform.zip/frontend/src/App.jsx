import { useEffect, useMemo, useState } from 'react';
import { Link, Navigate, Route, Routes, useLocation, useNavigate, useParams } from 'react-router-dom';
import api from './api/client';
import { useAuth } from './context/AuthContext';

const days = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];

const ProtectedRoute = ({ children, roles }) => {
  const { isAuthenticated, user } = useAuth();
  if (!isAuthenticated) return <Navigate to="/login" replace />;
  if (roles && !roles.includes(user?.role)) return <Navigate to="/" replace />;
  return children;
};

const Shell = ({ children }) => {
  const { user, logout, isAuthenticated } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();

  const onLogout = async () => {
    await logout();
    navigate('/login');
  };

  return (
    <div>
      <nav className="navbar navbar-expand-lg bg-white border-bottom sticky-top">
        <div className="container">
          <Link className="navbar-brand fw-bold text-primary" to="/">Local Services Pro</Link>
          <div className="d-flex flex-wrap gap-2 align-items-center">
            <Link className="btn btn-sm btn-outline-primary" to="/">Browse</Link>
            {isAuthenticated && user?.role === 'customer' && <Link className="btn btn-sm btn-outline-primary" to="/favorites">Favorites</Link>}
            {isAuthenticated && <Link className="btn btn-sm btn-outline-primary" to="/bookings">My Bookings</Link>}
            {isAuthenticated && user?.role === 'provider' && <Link className="btn btn-sm btn-outline-primary" to="/dashboard">Provider Dashboard</Link>}
            {isAuthenticated && <Link className="btn btn-sm btn-outline-primary" to="/notifications">Notifications</Link>}
            {isAuthenticated && <Link className="btn btn-sm btn-outline-primary" to="/profile">Profile</Link>}
            {!isAuthenticated && location.pathname !== '/login' && <Link className="btn btn-sm btn-outline-primary" to="/login">Login</Link>}
            {!isAuthenticated && location.pathname !== '/register' && <Link className="btn btn-sm btn-primary" to="/register">Register</Link>}
            {isAuthenticated && <button className="btn btn-sm btn-danger" onClick={onLogout}>Logout</button>}
          </div>
        </div>
      </nav>
      <main className="container py-4">{children}</main>
    </div>
  );
};

const AlertBlock = ({ error, success }) => (
  <>
    {error && <div className="alert alert-danger">{error}</div>}
    {success && <div className="alert alert-success">{success}</div>}
  </>
);

const AuthPage = ({ mode = 'login' }) => {
  const { login, register, user, isAuthenticated } = useAuth();
  const navigate = useNavigate();
  const [form, setForm] = useState({ name: '', email: '', password: '', role: 'customer', location: '', bio: '' });
  const [error, setError] = useState('');

  useEffect(() => {
    if (isAuthenticated && user) navigate('/');
  }, [isAuthenticated, user]);

  const submit = async (e) => {
    e.preventDefault();
    setError('');
    try {
      if (mode === 'login') await login({ email: form.email, password: form.password });
      else await register(form);
      navigate('/');
    } catch (err) {
      setError(err.response?.data?.message || 'Authentication failed.');
    }
  };

  return (
    <Shell>
      <div className="auth-card mx-auto shadow-sm bg-white p-4 rounded-4">
        <h2 className="mb-3">{mode === 'login' ? 'Welcome back' : 'Create account'}</h2>
        <AlertBlock error={error} />
        <form onSubmit={submit} className="row g-3">
          {mode === 'register' && (
            <>
              <div className="col-md-6"><input className="form-control" placeholder="Full name" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} required /></div>
              <div className="col-md-6"><select className="form-select" value={form.role} onChange={(e) => setForm({ ...form, role: e.target.value })}><option value="customer">Customer</option><option value="provider">Provider</option></select></div>
              <div className="col-12"><input className="form-control" placeholder="Location" value={form.location} onChange={(e) => setForm({ ...form, location: e.target.value })} /></div>
              <div className="col-12"><textarea className="form-control" rows="3" placeholder="Short bio" value={form.bio} onChange={(e) => setForm({ ...form, bio: e.target.value })} /></div>
            </>
          )}
          <div className="col-12"><input className="form-control" type="email" placeholder="Email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} required /></div>
          <div className="col-12"><input className="form-control" type="password" placeholder="Password" value={form.password} onChange={(e) => setForm({ ...form, password: e.target.value })} required /></div>
          <div className="col-12"><button className="btn btn-primary w-100">{mode === 'login' ? 'Login' : 'Register'}</button></div>
        </form>
      </div>
    </Shell>
  );
};

const HomePage = () => {
  const [filters, setFilters] = useState({ search: '', location: '', minRating: '', sort: 'latest', page: 1 });
  const [data, setData] = useState({ items: [], meta: { page: 1, totalPages: 1 } });
  const [loading, setLoading] = useState(true);

  const load = async () => {
    setLoading(true);
    const { data } = await api.get('/services', { params: filters });
    setData(data);
    setLoading(false);
  };

  useEffect(() => { load(); }, [filters.page]);

  const applyFilters = (e) => {
    e.preventDefault();
    setFilters((prev) => ({ ...prev, page: 1 }));
    load();
  };

  return (
    <Shell>
      <section className="hero-card p-4 p-md-5 rounded-4 mb-4">
        <div className="row align-items-center">
          <div className="col-lg-8">
            <h1 className="display-6 fw-bold">Find trusted local experts fast</h1>
            <p className="text-secondary mb-0">Search, sort, favorite providers, review ratings, and book secure appointments in one flow.</p>
          </div>
          <div className="col-lg-4 mt-3 mt-lg-0">
            <form className="row g-2" onSubmit={applyFilters}>
              <div className="col-12"><input className="form-control" placeholder="Search service or provider" value={filters.search} onChange={(e) => setFilters({ ...filters, search: e.target.value })} /></div>
              <div className="col-md-6"><input className="form-control" placeholder="Location" value={filters.location} onChange={(e) => setFilters({ ...filters, location: e.target.value })} /></div>
              <div className="col-md-6"><select className="form-select" value={filters.sort} onChange={(e) => setFilters({ ...filters, sort: e.target.value })}><option value="latest">Latest</option><option value="rating_desc">Highest rated</option><option value="price_asc">Lowest price</option><option value="availability_asc">Soonest availability</option></select></div>
              <div className="col-md-6"><input className="form-control" placeholder="Min rating" type="number" min="0" max="5" step="0.5" value={filters.minRating} onChange={(e) => setFilters({ ...filters, minRating: e.target.value })} /></div>
              <div className="col-md-6"><button className="btn btn-primary w-100">Apply filters</button></div>
            </form>
          </div>
        </div>
      </section>

      {loading ? <div>Loading services...</div> : (
        <>
          <div className="row g-4">
            {data.items.map((service) => (
              <div className="col-md-6 col-xl-4" key={service._id}>
                <div className="card h-100 shadow-sm border-0 rounded-4">
                  <div className="card-body d-flex flex-column">
                    <span className="badge text-bg-light w-fit mb-2">{service.category}</span>
                    <h5>{service.title}</h5>
                    <p className="text-secondary mb-2">{service.description}</p>
                    <div className="small text-secondary mb-2">Provider: {service.provider?.name} · {service.provider?.location || 'Remote'}</div>
                    <div className="small text-secondary mb-2">Rating: {(service.rating?.avgRating || 0).toFixed(1)} / 5</div>
                    <div className="small text-secondary mb-3">Open slots: {service.openSlots} · PKR {service.price}</div>
                    <div className="mt-auto d-flex gap-2">
                      <Link className="btn btn-outline-primary btn-sm" to={`/providers/${service.provider?._id}`}>View profile</Link>
                      <Link className="btn btn-primary btn-sm" to={`/book/${service._id}`}>Book now</Link>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
          <div className="d-flex justify-content-between align-items-center mt-4">
            <button className="btn btn-outline-secondary" disabled={filters.page <= 1} onClick={() => setFilters((prev) => ({ ...prev, page: prev.page - 1 }))}>Previous</button>
            <span>Page {data.meta.page} of {data.meta.totalPages}</span>
            <button className="btn btn-outline-secondary" disabled={filters.page >= data.meta.totalPages} onClick={() => setFilters((prev) => ({ ...prev, page: prev.page + 1 }))}>Next</button>
          </div>
        </>
      )}
    </Shell>
  );
};

const ProviderProfilePage = () => {
  const { providerId } = useParams();
  const { user, isAuthenticated, loadProfile } = useAuth();
  const [profile, setProfile] = useState(null);
  const [message, setMessage] = useState('');

  useEffect(() => {
    api.get(`/users/providers/${providerId}/public-profile`).then((res) => setProfile(res.data));
  }, [providerId]);

  const toggleFavorite = async () => {
    await api.post(`/users/favorites/${providerId}`);
    await loadProfile();
    setMessage('Favorites updated.');
  };

  if (!profile) return <Shell>Loading provider...</Shell>;
  const isFavorite = user?.favoriteProviders?.some((item) => item._id === providerId || item === providerId);

  return (
    <Shell>
      <AlertBlock success={message} />
      <div className="card border-0 shadow-sm rounded-4 mb-4"><div className="card-body">
        <div className="d-flex flex-wrap justify-content-between gap-3">
          <div>
            <h2 className="mb-1">{profile.provider.name}</h2>
            <p className="text-secondary mb-1">{profile.provider.location || 'Location not set'}</p>
            <p className="mb-0">{profile.provider.bio || 'No bio added yet.'}</p>
          </div>
          <div>
            <div className="fw-semibold">Average rating: {(profile.rating.avgRating || 0).toFixed(1)}</div>
            <div className="text-secondary">Reviews: {profile.rating.reviewCount || 0}</div>
            <div className="text-secondary">Completion rate: {profile.stats.completionRate}%</div>
            {isAuthenticated && user?.role === 'customer' && <button className="btn btn-outline-primary btn-sm mt-2" onClick={toggleFavorite}>{isFavorite ? 'Remove favorite' : 'Save favorite'}</button>}
          </div>
        </div>
      </div></div>
      <div className="row g-4">
        <div className="col-lg-6">
          <div className="card border-0 shadow-sm rounded-4 h-100"><div className="card-body">
            <h4>Services</h4>
            <div className="list-group list-group-flush">
              {profile.services.map((service) => <Link className="list-group-item list-group-item-action border-0 px-0" key={service._id} to={`/book/${service._id}`}>{service.title} — PKR {service.price}</Link>)}
            </div>
          </div></div>
        </div>
        <div className="col-lg-6">
          <div className="card border-0 shadow-sm rounded-4 h-100"><div className="card-body">
            <h4>Availability</h4>
            <div className="d-flex flex-wrap gap-2">{profile.availability.map((slot) => <span className={`badge ${slot.isBooked ? 'text-bg-secondary' : 'text-bg-success'}`} key={slot._id}>{days[slot.dayOfWeek]} {slot.startTime}-{slot.endTime}</span>)}</div>
          </div></div>
        </div>
      </div>
      <div className="card border-0 shadow-sm rounded-4 mt-4"><div className="card-body">
        <h4>Reviews</h4>
        <div className="row g-3">{profile.reviews.map((review) => <div className="col-md-6" key={review._id}><div className="border rounded-3 p-3 h-100"><div className="fw-semibold">{review.customerId?.name}</div><div className="small text-secondary mb-2">Rating: {review.rating}/5</div><div>{review.comment}</div></div></div>)}</div>
      </div></div>
    </Shell>
  );
};

const BookingPage = () => {
  const { serviceId } = useParams();
  const [service, setService] = useState(null);
  const [availability, setAvailability] = useState([]);
  const [slotId, setSlotId] = useState('');
  const [notes, setNotes] = useState('');
  const [message, setMessage] = useState('');
  const [error, setError] = useState('');

  useEffect(() => {
    const load = async () => {
      const { data } = await api.get(`/services/${serviceId}`);
      setService(data);
      const slots = await api.get(`/availability/${data.providerId._id}`);
      setAvailability(slots.data.filter((item) => !item.isBooked));
    };
    load();
  }, [serviceId]);

  const book = async (e) => {
    e.preventDefault();
    setError('');
    try {
      await api.post('/bookings', { serviceId, slotId, notes });
      setMessage('Booking request submitted successfully.');
    } catch (err) {
      setError(err.response?.data?.message || 'Booking failed.');
    }
  };

  if (!service) return <Shell>Loading booking checkout...</Shell>;

  return (
    <Shell>
      <div className="row g-4">
        <div className="col-lg-5"><div className="card border-0 shadow-sm rounded-4"><div className="card-body">
          <span className="badge text-bg-light mb-2">{service.category}</span>
          <h3>{service.title}</h3>
          <p>{service.description}</p>
          <div className="text-secondary">Provider: {service.providerId.name}</div>
          <div className="text-secondary">Duration: {service.durationMinutes} mins</div>
          <div className="fw-semibold mt-2">PKR {service.price}</div>
        </div></div></div>
        <div className="col-lg-7"><div className="card border-0 shadow-sm rounded-4"><div className="card-body">
          <h4>Select slot</h4>
          <AlertBlock error={error} success={message} />
          <form onSubmit={book} className="row g-3">
            <div className="col-12"><select className="form-select" value={slotId} onChange={(e) => setSlotId(e.target.value)} required><option value="">Choose a slot</option>{availability.map((slot) => <option key={slot._id} value={slot._id}>{days[slot.dayOfWeek]} {slot.startTime}-{slot.endTime}</option>)}</select></div>
            <div className="col-12"><textarea className="form-control" rows="4" value={notes} placeholder="Optional booking notes" onChange={(e) => setNotes(e.target.value)} /></div>
            <div className="col-12"><button className="btn btn-primary">Submit booking request</button></div>
          </form>
        </div></div></div>
      </div>
    </Shell>
  );
};

const BookingsPage = () => {
  const { user } = useAuth();
  const [bookings, setBookings] = useState([]);
  const [reviews, setReviews] = useState({});
  const [message, setMessage] = useState('');

  const load = async () => {
    const { data } = await api.get('/bookings/me');
    setBookings(data);
  };
  useEffect(() => { load(); }, []);

  const updateStatus = async (bookingId, status) => {
    await api.put(`/bookings/${bookingId}/status`, { status });
    setMessage('Booking updated successfully.');
    load();
  };

  const submitReview = async (booking) => {
    const payload = reviews[booking._id];
    await api.post('/reviews', { bookingId: booking._id, providerId: booking.providerId._id, rating: Number(payload.rating), comment: payload.comment });
    setMessage('Review submitted.');
    load();
  };

  return (
    <Shell>
      <div className="d-flex justify-content-between align-items-center mb-3"><h2>My Bookings</h2><a className="btn btn-outline-primary" href={`${import.meta.env.VITE_API_URL || 'http://localhost:5000/api'}/bookings/export/csv`} target="_blank">Export CSV</a></div>
      <AlertBlock success={message} />
      <div className="row g-4">
        {bookings.map((booking) => (
          <div className="col-12" key={booking._id}>
            <div className="card border-0 shadow-sm rounded-4"><div className="card-body">
              <div className="d-flex flex-wrap justify-content-between gap-3">
                <div>
                  <h5>{booking.serviceId?.title}</h5>
                  <div className="text-secondary small">{days[booking.slotSnapshot?.dayOfWeek]} {booking.slotSnapshot?.startTime}-{booking.slotSnapshot?.endTime}</div>
                  <div className="text-secondary small">Provider: {booking.providerId?.name} | Customer: {booking.customerId?.name}</div>
                </div>
                <span className="badge text-bg-light text-uppercase">{booking.status}</span>
              </div>
              <div className="mt-3 d-flex flex-wrap gap-2">
                {user?.role === 'provider' && booking.status === 'pending' && <button className="btn btn-sm btn-success" onClick={() => updateStatus(booking._id, 'confirmed')}>Confirm</button>}
                {user?.role === 'provider' && booking.status === 'pending' && <button className="btn btn-sm btn-outline-danger" onClick={() => updateStatus(booking._id, 'declined')}>Decline</button>}
                {user?.role === 'provider' && booking.status === 'confirmed' && <button className="btn btn-sm btn-primary" onClick={() => updateStatus(booking._id, 'completed')}>Mark completed</button>}
                {user?.role === 'customer' && ['pending', 'confirmed'].includes(booking.status) && <button className="btn btn-sm btn-outline-danger" onClick={() => updateStatus(booking._id, 'cancelled')}>Cancel</button>}
              </div>
              {user?.role === 'customer' && booking.status === 'completed' && (
                <div className="mt-4 border-top pt-3 row g-2">
                  <div className="col-md-2"><input className="form-control" type="number" min="1" max="5" placeholder="Rating" value={reviews[booking._id]?.rating || ''} onChange={(e) => setReviews({ ...reviews, [booking._id]: { ...reviews[booking._id], rating: e.target.value } })} /></div>
                  <div className="col-md-8"><input className="form-control" placeholder="Review comment" value={reviews[booking._id]?.comment || ''} onChange={(e) => setReviews({ ...reviews, [booking._id]: { ...reviews[booking._id], comment: e.target.value } })} /></div>
                  <div className="col-md-2"><button className="btn btn-primary w-100" onClick={() => submitReview(booking)}>Submit</button></div>
                </div>
              )}
            </div></div>
          </div>
        ))}
      </div>
    </Shell>
  );
};

const DashboardPage = () => {
  const [stats, setStats] = useState(null);
  const [bookings, setBookings] = useState([]);
  const [services, setServices] = useState([]);
  const [availability, setAvailability] = useState([]);
  const [message, setMessage] = useState('');
  const [serviceForm, setServiceForm] = useState({ title: '', description: '', category: '', durationMinutes: 60, price: 0, isActive: true });
  const [slotForm, setSlotForm] = useState({ dayOfWeek: 1, startTime: '10:00', endTime: '11:00' });

  const load = async () => {
    const [statsRes, bookingsRes, servicesRes, profileRes] = await Promise.all([
      api.get('/dashboard/provider-stats'),
      api.get('/bookings/me'),
      api.get('/services', { params: { limit: 50 } }),
      api.get('/users/profile'),
    ]);
    setStats(statsRes.data);
    setBookings(bookingsRes.data);
    setServices(servicesRes.data.items.filter((item) => item.provider?._id === profileRes.data._id));
    const slots = await api.get(`/availability/${profileRes.data._id}`);
    setAvailability(slots.data);
  };

  useEffect(() => { load(); }, []);

  const addService = async (e) => {
    e.preventDefault();
    await api.post('/services', { ...serviceForm, price: Number(serviceForm.price), durationMinutes: Number(serviceForm.durationMinutes) });
    setMessage('Service added.');
    setServiceForm({ title: '', description: '', category: '', durationMinutes: 60, price: 0, isActive: true });
    load();
  };

  const saveAvailability = async () => {
    const updated = [...availability, { ...slotForm, dayOfWeek: Number(slotForm.dayOfWeek) }];
    await api.post('/availability', { slots: updated.map((slot) => ({ dayOfWeek: Number(slot.dayOfWeek), startTime: slot.startTime, endTime: slot.endTime })) });
    setMessage('Availability saved.');
    setSlotForm({ dayOfWeek: 1, startTime: '10:00', endTime: '11:00' });
    load();
  };

  const changeStatus = async (bookingId, status) => {
    await api.put(`/bookings/${bookingId}/status`, { status });
    setMessage('Booking status updated.');
    load();
  };

  return (
    <Shell>
      <h2 className="mb-3">Provider Dashboard</h2>
      <AlertBlock success={message} />
      <div className="row g-4 mb-4">
        {stats && ['totalBookings', 'completedBookings', 'pendingBookings', 'completionRate'].map((key) => <div className="col-md-3" key={key}><div className="card border-0 shadow-sm rounded-4"><div className="card-body"><div className="text-secondary text-capitalize">{key.replace(/([A-Z])/g, ' $1')}</div><div className="display-6 fw-bold">{stats[key]}{key === 'completionRate' ? '%' : ''}</div></div></div></div>)}
      </div>
      <div className="row g-4">
        <div className="col-lg-6"><div className="card border-0 shadow-sm rounded-4 h-100"><div className="card-body"><h4>Add Service</h4><form className="row g-2" onSubmit={addService}><div className="col-12"><input className="form-control" placeholder="Title" value={serviceForm.title} onChange={(e) => setServiceForm({ ...serviceForm, title: e.target.value })} required /></div><div className="col-12"><textarea className="form-control" placeholder="Description" value={serviceForm.description} onChange={(e) => setServiceForm({ ...serviceForm, description: e.target.value })} required /></div><div className="col-md-6"><input className="form-control" placeholder="Category" value={serviceForm.category} onChange={(e) => setServiceForm({ ...serviceForm, category: e.target.value })} required /></div><div className="col-md-3"><input className="form-control" type="number" min="15" placeholder="Duration" value={serviceForm.durationMinutes} onChange={(e) => setServiceForm({ ...serviceForm, durationMinutes: e.target.value })} required /></div><div className="col-md-3"><input className="form-control" type="number" min="0" placeholder="Price" value={serviceForm.price} onChange={(e) => setServiceForm({ ...serviceForm, price: e.target.value })} required /></div><div className="col-12"><button className="btn btn-primary">Add service</button></div></form><hr /><h5>Existing Services</h5><ul className="list-group list-group-flush">{services.map((service) => <li className="list-group-item px-0" key={service._id}>{service.title} — PKR {service.price}</li>)}</ul></div></div></div>
        <div className="col-lg-6"><div className="card border-0 shadow-sm rounded-4 h-100"><div className="card-body"><h4>Weekly Availability</h4><div className="row g-2 mb-3"><div className="col-md-4"><select className="form-select" value={slotForm.dayOfWeek} onChange={(e) => setSlotForm({ ...slotForm, dayOfWeek: e.target.value })}>{days.map((day, index) => <option key={day} value={index}>{day}</option>)}</select></div><div className="col-md-4"><input className="form-control" type="time" value={slotForm.startTime} onChange={(e) => setSlotForm({ ...slotForm, startTime: e.target.value })} /></div><div className="col-md-4"><input className="form-control" type="time" value={slotForm.endTime} onChange={(e) => setSlotForm({ ...slotForm, endTime: e.target.value })} /></div><div className="col-12"><button className="btn btn-outline-primary" onClick={saveAvailability}>Save slot</button></div></div><div className="d-flex flex-wrap gap-2">{availability.map((slot) => <span key={slot._id} className={`badge ${slot.isBooked ? 'text-bg-secondary' : 'text-bg-success'}`}>{days[slot.dayOfWeek]} {slot.startTime}-{slot.endTime}</span>)}</div></div></div></div>
      </div>
      <div className="card border-0 shadow-sm rounded-4 mt-4"><div className="card-body"><h4>Incoming Requests</h4><div className="row g-3">{bookings.map((booking) => <div className="col-md-6" key={booking._id}><div className="border rounded-3 p-3 h-100"><div className="fw-semibold">{booking.serviceId?.title}</div><div className="small text-secondary mb-2">{booking.customerId?.name} · {booking.status}</div><div className="d-flex gap-2 flex-wrap">{booking.status === 'pending' && <button className="btn btn-sm btn-success" onClick={() => changeStatus(booking._id, 'confirmed')}>Confirm</button>}{booking.status === 'pending' && <button className="btn btn-sm btn-outline-danger" onClick={() => changeStatus(booking._id, 'declined')}>Decline</button>}{booking.status === 'confirmed' && <button className="btn btn-sm btn-primary" onClick={() => changeStatus(booking._id, 'completed')}>Complete</button>}</div></div></div>)}</div></div></div>
    </Shell>
  );
};

const ProfilePage = () => {
  const { user, loadProfile } = useAuth();
  const [profile, setProfile] = useState({ name: '', bio: '', location: '', profilePicUrl: '' });
  const [passwords, setPasswords] = useState({ currentPassword: '', newPassword: '' });
  const [message, setMessage] = useState('');

  useEffect(() => {
    if (user) setProfile({ name: user.name || '', bio: user.bio || '', location: user.location || '', profilePicUrl: user.profilePicUrl || '' });
  }, [user]);

  const saveProfile = async (e) => {
    e.preventDefault();
    await api.put('/users/profile', profile);
    await loadProfile();
    setMessage('Profile updated.');
  };

  const changePassword = async (e) => {
    e.preventDefault();
    await api.put('/users/change-password', passwords);
    setMessage('Password changed successfully.');
    setPasswords({ currentPassword: '', newPassword: '' });
  };

  return (
    <Shell>
      <h2 className="mb-3">My Profile</h2>
      <AlertBlock success={message} />
      <div className="row g-4">
        <div className="col-lg-7"><div className="card border-0 shadow-sm rounded-4"><div className="card-body"><form className="row g-3" onSubmit={saveProfile}><div className="col-md-6"><input className="form-control" placeholder="Name" value={profile.name} onChange={(e) => setProfile({ ...profile, name: e.target.value })} /></div><div className="col-md-6"><input className="form-control" placeholder="Location" value={profile.location} onChange={(e) => setProfile({ ...profile, location: e.target.value })} /></div><div className="col-12"><input className="form-control" placeholder="Profile image URL" value={profile.profilePicUrl} onChange={(e) => setProfile({ ...profile, profilePicUrl: e.target.value })} /></div><div className="col-12"><textarea className="form-control" rows="4" placeholder="Bio" value={profile.bio} onChange={(e) => setProfile({ ...profile, bio: e.target.value })} /></div><div className="col-12"><button className="btn btn-primary">Save profile</button></div></form></div></div></div>
        <div className="col-lg-5"><div className="card border-0 shadow-sm rounded-4"><div className="card-body"><form className="row g-3" onSubmit={changePassword}><div className="col-12"><input className="form-control" type="password" placeholder="Current password" value={passwords.currentPassword} onChange={(e) => setPasswords({ ...passwords, currentPassword: e.target.value })} /></div><div className="col-12"><input className="form-control" type="password" placeholder="New password" value={passwords.newPassword} onChange={(e) => setPasswords({ ...passwords, newPassword: e.target.value })} /></div><div className="col-12"><button className="btn btn-outline-primary">Change password</button></div></form></div></div></div>
      </div>
    </Shell>
  );
};

const NotificationsPage = () => {
  const [notifications, setNotifications] = useState([]);
  useEffect(() => { api.get('/notifications').then((res) => setNotifications(res.data)); }, []);
  return <Shell><h2 className="mb-3">Notifications</h2><div className="row g-3">{notifications.map((item) => <div className="col-md-6" key={item._id}><div className="card border-0 shadow-sm rounded-4"><div className="card-body"><div className="fw-semibold">{item.title}</div><div className="text-secondary small mb-2">{new Date(item.createdAt).toLocaleString()}</div><div>{item.message}</div></div></div></div>)}</div></Shell>;
};

const FavoritesPage = () => {
  const { user } = useAuth();
  const favorites = user?.favoriteProviders || [];
  return <Shell><h2 className="mb-3">Saved Providers</h2><div className="row g-3">{favorites.map((provider) => <div className="col-md-6" key={provider._id}><div className="card border-0 shadow-sm rounded-4"><div className="card-body"><h5>{provider.name}</h5><p className="text-secondary">{provider.location}</p><p>{provider.bio}</p><Link className="btn btn-outline-primary btn-sm" to={`/providers/${provider._id}`}>Open profile</Link></div></div></div>)}{!favorites.length && <p>No favorites yet.</p>}</div></Shell>;
};

export default function App() {
  return (
    <Routes>
      <Route path="/" element={<HomePage />} />
      <Route path="/login" element={<AuthPage mode="login" />} />
      <Route path="/register" element={<AuthPage mode="register" />} />
      <Route path="/providers/:providerId" element={<ProviderProfilePage />} />
      <Route path="/book/:serviceId" element={<ProtectedRoute roles={['customer']}><BookingPage /></ProtectedRoute>} />
      <Route path="/bookings" element={<ProtectedRoute><BookingsPage /></ProtectedRoute>} />
      <Route path="/dashboard" element={<ProtectedRoute roles={['provider']}><DashboardPage /></ProtectedRoute>} />
      <Route path="/profile" element={<ProtectedRoute><ProfilePage /></ProtectedRoute>} />
      <Route path="/notifications" element={<ProtectedRoute><NotificationsPage /></ProtectedRoute>} />
      <Route path="/favorites" element={<ProtectedRoute roles={['customer']}><FavoritesPage /></ProtectedRoute>} />
      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  );
}
